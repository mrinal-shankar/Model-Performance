#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from setuptools import setup, find_packages

VERSION = '0.0.1' 
DESCRIPTION = 'Model Analysis and Performance Package'
LONG_DESCRIPTION = 'Calculates confusion matrix at decile level'

setup(
       # the name must match the folder name 'verysimplemodule'
        name="model_performance", 
        version=VERSION,
        author="Mrinal Shankar",
        author_email="<mrinal.svp@gmail.com>",
        description=DESCRIPTION,
        long_description=LONG_DESCRIPTION,
        packages=find_packages(),
        install_requires=['numpy', 'pandas'], # add any additional packages that 
        # needs to be installed along with your package. Eg: 'caer'
        
        keywords=['python', 'model performance'],
        classifiers= [
            "Development Status :: 3 - Alpha",
            "Intended Audience :: Professional",
            "Programming Language :: Python :: 2",
            "Programming Language :: Python :: 3",
            "Operating System :: MacOS :: MacOS X",
            "Operating System :: Microsoft :: Windows",
        ]
)

